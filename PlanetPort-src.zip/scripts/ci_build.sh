#!/usr/bin/env bash
# PlanetPort - native iOS frontend for the Azahar 3DS emulator core.
# Copyright 2026 PlanetPort contributors. Licensed under GPLv2 or any later version.
#
# Full CI build on a macOS machine (used by .github/workflows/build-ios.yml):
# tools -> PlanetCore.framework -> Xcode project -> unsigned PlanetPort.ipa.
#
#   bash scripts/ci_build.sh [output.ipa]

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_IPA="${1:-$ROOT/PlanetPort.ipa}"

echo "==> Tools"
export HOMEBREW_NO_AUTO_UPDATE=1
export HOMEBREW_NO_INSTALL_CLEANUP=1
brew install ninja xcodegen ccache
xcodebuild -version
cmake --version | head -n1
python3 --version

echo "==> Compiler cache"
export CCACHE_DIR="${CCACHE_DIR:-$ROOT/.ccache}"
export CCACHE_MAXSIZE="${CCACHE_MAXSIZE:-3G}"
export CCACHE_COMPRESS=1
export CMAKE_C_COMPILER_LAUNCHER=ccache
export CMAKE_CXX_COMPILER_LAUNCHER=ccache
export CMAKE_OBJC_COMPILER_LAUNCHER=ccache
export CMAKE_OBJCXX_COMPILER_LAUNCHER=ccache

echo "==> PlanetCore.framework"
bash "$ROOT/scripts/build_core.sh"
ccache --show-stats || true

echo "==> Xcode project"
(cd "$ROOT/App" && xcodegen generate)

echo "==> App (unsigned)"
mkdir -p "$ROOT/build"
xcodebuild \
    -project "$ROOT/App/PlanetPort.xcodeproj" \
    -target PlanetPort \
    -configuration Release \
    -sdk iphoneos \
    SYMROOT="$ROOT/build/xcode" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY="" \
    DEVELOPMENT_TEAM="" \
    build 2>&1 | tee "$ROOT/build/xcodebuild.log"

echo "==> IPA"
APP="$ROOT/build/xcode/Release-iphoneos/PlanetPort.app"
[[ -d "$APP" ]] || { echo "error: PlanetPort.app not found" >&2; exit 1; }
[[ -f "$APP/Frameworks/PlanetCore.framework/PlanetCore" ]] \
    || { echo "error: PlanetCore.framework was not embedded" >&2; exit 1; }
rm -rf "$ROOT/build/ipa"
mkdir -p "$ROOT/build/ipa/Payload"
cp -R "$APP" "$ROOT/build/ipa/Payload/"
rm -f "$OUTPUT_IPA"
(cd "$ROOT/build/ipa" && zip -qry "$OUTPUT_IPA" Payload)
ls -lh "$OUTPUT_IPA"
echo "==> Done: $OUTPUT_IPA"
